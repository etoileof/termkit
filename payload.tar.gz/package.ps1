# CI: assemble termkit-<version>-windows-x64.zip from out/ and payload/, run from the workspace root.
param([Parameter(Mandatory = $true)][string]$Version)

$ErrorActionPreference = 'Stop'
$name = "termkit-$Version-windows-x64"
$stage = Join-Path $env:RUNNER_TEMP $name
New-Item -ItemType Directory -Force -Path $stage | Out-Null
Copy-Item 'out/kimi.exe', 'out/LICENSE-upstream.txt' $stage
Copy-Item 'payload/windows/*' $stage
Copy-Item 'payload/config.toml.example' $stage
$sha = $env:GITHUB_SHA.Substring(0, 7)
[IO.File]::WriteAllText((Join-Path $stage 'version.txt'), "$Version (build $env:GITHUB_RUN_NUMBER, $sha)")

$leaks = Get-ChildItem $stage -File | Where-Object Extension -ne '.exe' |
  Select-String -Pattern 'closerouter_[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{40,}' -List
if ($leaks) { throw "Refusing to package: an API key was found in $($leaks.Path -join ', ')" }

$zip = Join-Path $env:RUNNER_TEMP "$name.zip"
Compress-Archive -Path $stage -DestinationPath $zip -CompressionLevel Optimal
Get-ChildItem $stage | Format-Table Name, Length
"name=$name" >> $env:GITHUB_OUTPUT
"zip=$zip" >> $env:GITHUB_OUTPUT
"package=$stage" >> $env:GITHUB_OUTPUT
