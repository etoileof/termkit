#!/usr/bin/env bash
# CI build steps, run from the workflow's workspace root.
#   build.sh fetch   clone the base release into source/ and apply patches/
#   build.sh build   build the native Windows executable, smoke-test it, copy it to out/
set -euo pipefail

payload=$(cd "$(dirname "$0")" && pwd)
. "$payload/upstream.env"
version=$(tr -d '[:space:]' < "$payload/BASE_VERSION")

case "${1:-}" in
  fetch)
    git clone --depth 1 --branch "${UPSTREAM_TAG_PREFIX}${version}" "$UPSTREAM_REPO" source
    git -C source -c user.name=build -c user.email=build@localhost am --3way "$payload"/patches/*.patch
    git -C source log --oneline -n "$(ls "$payload"/patches/*.patch | wc -l)"
    echo "version=$version" >> "$GITHUB_OUTPUT"
    ;;
  build)
    cd source
    node "$APP_DIR/scripts/check-web-assets.mjs"
    KIMI_AZURE_TRUSTED_SIGNING=false pnpm --filter "$APP_FILTER" run build:native:sea
    pnpm --filter "$APP_FILTER" run test:native:smoke
    mkdir -p ../out
    cp "$APP_DIR/dist-native/bin/win32-x64/kimi.exe" ../out/kimi.exe
    cp LICENSE ../out/LICENSE-upstream.txt
    ;;
  *)
    echo "usage: build.sh fetch|build" >&2
    exit 2
    ;;
esac
